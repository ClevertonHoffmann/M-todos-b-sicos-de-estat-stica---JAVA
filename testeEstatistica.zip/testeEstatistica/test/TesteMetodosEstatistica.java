/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileNotFoundException;
import java.util.ArrayList;
import junit.framework.TestCase;
import static junit.framework.TestCase.assertEquals;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
import testeestatistica.JsonValores;
import testeestatistica.MetodosDeEstatistica;

/**
 * Classe de testes unitários
 * @author Cleverton
 */
public class TesteMetodosEstatistica extends TestCase{
    
    MetodosDeEstatistica m = new MetodosDeEstatistica();
    JsonValores j = new JsonValores();
    ArrayList<String> l = new ArrayList();
    
    public void testMedia() throws FileNotFoundException {
                l.add("1.0");
                l.add("2.0");
                l.add("3.0");
                j.inserir(l);
		assertEquals(2.0, m.Media(j.lerJson()));
    }
    
    public void testMediana() {
		l.add("1.0");
                l.add("2.0");
                l.add("3.0");
                l.add("4.0");
                l.add("5.0");
                l.add("6.0");
                l.add("7.0");
                l.add("8.0");
                j.inserir(l);
		assertEquals(5.5, m.Mediana(j.lerJson()));
    }
    
    public void testModa() {
		l.add("1.0");
                l.add("2.0");
                l.add("3.0");
                l.add("4.0");
                l.add("3.0");
                l.add("6.0");
                l.add("3.0");
                l.add("8.0");
                j.inserir(l);
		assertEquals(3.0, m.Moda(j.lerJson()));
    }
    
    public void testVarianca() {
		l.add("1.0");
                l.add("10.0");
                l.add("10");
                j.inserir(l);
		assertEquals(18.0, m.Varianca(j.lerJson()));
    }
    
    public void testDesvioPadrao() {
                l.add("10.0");
                l.add("8.0");
                l.add("8.0");
                l.add("10.0");
                l.add("8.0");      
                l.add("4.0");
                j.inserir(l);
		assertEquals(2.0, m.DesvioPadrao(j.lerJson()));
    }
}
