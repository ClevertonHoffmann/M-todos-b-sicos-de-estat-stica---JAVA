/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testeestatistica;
import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Cleverton
 */
public class JsonValores {

    public List<String> lerJson() {

        List<String> lista = new ArrayList<String>();

        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        System.out.println(gson.toJson(lista));
        builder = new GsonBuilder();
        gson = builder.create();
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader("C:\\Users\\Cleverton\\Desktop\\testeEstatistica\\src\\Valores.json"));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JsonValores.class.getName()).log(Level.SEVERE, null, ex);
        }

        Type listType = new TypeToken<ArrayList<String>>() {
        }.getType();

        lista = new ArrayList<String>();

        lista = new Gson().fromJson(bufferedReader, listType);

        return lista;

    }

     public boolean inserir(List<String> lista) {
        
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            FileWriter writer;
        try {
            writer = new FileWriter("C:\\Users\\Cleverton\\Desktop\\testeEstatistica\\src\\Valores.json");
            writer.write(gson.toJson(lista));
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(JsonValores.class.getName()).log(Level.SEVERE, null, ex);
        }
            return true;
    }
    
}
