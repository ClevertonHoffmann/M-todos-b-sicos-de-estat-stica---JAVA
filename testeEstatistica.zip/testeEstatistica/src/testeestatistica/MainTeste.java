/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testeestatistica;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Cleverton
 */
public class MainTeste {

    public static void main(String[] args) throws IOException {
       
        
        JsonValores j = new JsonValores();
        ArrayList<String> l = new ArrayList();  
        MetodosDeEstatistica m = new MetodosDeEstatistica();
        l.add("1.0");
        l.add("2.0");
        l.add("3.0");
        l.add("4.0");
        l.add("5.0");
        l.add("20.0");
        j.inserir(l);
        
        System.out.println(m.DesvioPadrao(j.lerJson()));
        
        
        
    }
}
