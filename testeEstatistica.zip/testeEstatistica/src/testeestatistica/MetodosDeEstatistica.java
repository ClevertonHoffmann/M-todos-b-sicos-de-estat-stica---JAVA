package testeestatistica;


import java.io.FileNotFoundException;
import java.util.List;

/**
 * Classe responsável por calcular Média, Mediana, Moda, Varianca e Desvio Padrão de um conjunto de dados de uma lista
 * @author Cleverton
 */
public class MetodosDeEstatistica {
    
  //  private List<String> lista;
    
    public MetodosDeEstatistica() {
       // JsonValores j = new JsonValores();
       // lista = j.lerJson();
    }
    
    /**
     * Média é a soma de todos valore dividido pela quantidade deles
     * @param lista
     * @return double
     */
    public double Media(List<String> lista){
        double soma = 0;
        if(lista != null){
        for (String i: lista){
            soma = soma + Double.parseDouble(i);
        }
        return soma/lista.size();
        }
        return 0.0;
    }
    
    /**
     * Mediana é o valor do meio no conjuto ordenado de dados, ou a media dos dois valores do meio
     * @param lista
     * @return Double
     */
    public double Mediana(List<String> lista){
        //Ordena Vetor
        if(lista!=null){
            double aux = 0.0;              
            for (int i = 0; i < lista.size(); i++)
            {
                for (int j = 0; j < lista.size(); j++)
                {
                    if (Double.parseDouble(lista.get(i))<Double.parseDouble(lista.get(j)))
                    {
                        aux = Double.parseDouble(lista.get(i));
                        lista.set(i, lista.get(j));
                        lista.set(j, String.valueOf(aux));
                    }
                }
            }
        if(lista.size()%2 == 0){
            return (Double.parseDouble(lista.get(lista.size()/2))+Double.parseDouble(lista.get((lista.size()/2)+1)))/2;
        } else{
            return Double.parseDouble(lista.get(lista.size()/2));
        }
        }
        return 0.0;
    }
    
    /**
     * Moda é o valor que mais aparece no conjunto de dados.
     * @param lista
     * @return double
     */
    public double Moda(List<String> lista){
        double aux = 0.0;
        int qnt = 0;
        if(lista != null){
        int[] vetor = new int[lista.size()];
        for (int i = 0; i < lista.size(); i++)
        {
            aux = Double.parseDouble(lista.get(i));
            for (int j = 1; j < lista.size(); j++)
            {    
                if(aux == Double.parseDouble(lista.get(j))){
                    qnt++;
                }       
            }
            vetor[i] = qnt;           
            qnt = 0;
        }
        int aux2 = 0;
        for (int i = 0; i < lista.size(); i++){
            if(vetor[i]>aux2){
                aux = Double.parseDouble(lista.get(i));
                aux2 = vetor[i];
            }
        }
        return aux;
        }
        return 0.0;
    }

    /**
     * É a raiz quadrada da variança
     * @param lista
     * @return double
     */
    public double DesvioPadrao(List<String> lista){
        if(lista!=null){
            return Math.sqrt(Varianca(lista));
        }
        return 0.0;
    }
    
    /**
     * É a soma  de (cada elemento menos a média elevado ao quadrado) dividido pelaquantidade de dados de entrada
     * @param lista
     * @return Double
     */
    public double Varianca(List<String> lista){
        if(lista!=null){
        double media = Media(lista);
        double soma = 0;
        for (int i = 0; i < lista.size(); i++){
            soma = soma + (Math.pow(Double.parseDouble(lista.get(i))-media, 2));
        }
            return soma/lista.size();
        }
        return 0.0;
    }
}
